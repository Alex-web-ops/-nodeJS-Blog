const http = require('http');//获取htto请求
const querystring =require('querystring');//获取querystring请求
const server = http.createServer((req,res)=>{
    console.log('method:',req.method) //输出为GET
    const url = (req.url) //获取完整的Url
    console.log(url)
    querystring.parreq.query=se(url.split('?')[1])//解析queryString
    console.log(req.query)
    res.end(JSON.stringify(req.query));//将 queryString 返回
});
server.listen(8000);
console.log('OK');