const http = require('http')
const server = http.createServer((req,res)=>{
    if(req.method === 'POST'){
        //数据格式为JSON
        console.log('content-type',req.headers['content-type'])
        //接收数据
        let postData=""
        //一有data,便把接收到的字符串拼接起来
        req.on('data',chunk=>{
            postData += chunk.toString()
        })
        //结束之后，会唤起end请求
        req.on('end',()=>{
            console.log(postData)
            res.end('hello world !');//在这里返回,因为是异步
        })
    }
});
server.listen(8000);
console.log('OK')