//koa框架调试
const router  = require('koa-router')()
//路由
router.get('/',async)(ctx,next=>
    {console.log(200)
     console.log(300)
     console.log(400)
     await ctx.render('index',{
         titile:'Hello Koa 2'
     })

    })
router.get('string',async(ctx,next)=>{
    ctx.body = 'koa2 string'
})
router.get('/json',async(ctx,next)=>{
    console.log(100)
    console.log(200)
    console.log(300)
    console.log(400)
    ctx.body ={
        titile: 'koa2 json'
    }
})