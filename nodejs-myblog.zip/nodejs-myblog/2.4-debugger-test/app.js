//nodejs http 基础代码
//注意一共向浏览器发送两个请求，一个是HTTP请求，一个是ico请求
const http = require('http')//nodejs自带的require http
const server = http.createServer((req,res) =>{
    res.writeHead(200,{'content-type': 'text/html'})
    res.end('<h1>hello word</h1>')
}) 
server.listen(3000,()=>{
    console.log('listening on 3000 port')
})//监听3000端口