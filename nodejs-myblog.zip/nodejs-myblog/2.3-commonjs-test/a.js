function add(a,b){
return a +b
}
function mul(a,b){
  return a*b
}

module.exports = {
    add, 
    mul
}//类似于数组的方式导出加法和乘法方法