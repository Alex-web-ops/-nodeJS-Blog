const serverHandle = (req,res) => {
    //设置返回格式设置成JSON
    res.setHeader('Content-type','application/json')
    //定义返回的内容
    const resData = {
        name:'Ze1Sure',
        site:'mooc'
        }
    //转换成字符串
    res.end(
        JSON.stringify(resData)
    )
}
module.exports=serverHandle